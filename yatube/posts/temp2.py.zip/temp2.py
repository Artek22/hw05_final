def solution(node):
    while node:
        print(node.value)
        node = node.next_item